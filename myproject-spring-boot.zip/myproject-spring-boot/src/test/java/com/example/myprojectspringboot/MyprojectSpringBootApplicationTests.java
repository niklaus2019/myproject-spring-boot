package com.example.myprojectspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyprojectSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
