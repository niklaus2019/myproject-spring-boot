package com.example.myprojectspringboot;

import org.postgresql.Driver;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyprojectSpringBootApplication {

    public static void main(String[] args) {

        SpringApplication.run(MyprojectSpringBootApplication.class, args);
        System.out.println("prinl");

    }

}
